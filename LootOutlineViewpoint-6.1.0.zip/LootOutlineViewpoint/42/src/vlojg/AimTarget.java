package vlojg;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

import viewpoint.core.Frame;
import viewpoint.render.SceneData;
import viewpoint.world.ChunkCache;
import zombie.iso.IsoGridSquare;
import zombie.iso.sprite.IsoSprite;

/**
 * Keeps the outline on the aimed loot only.
 *
 * Viewpoint clears Frame.lootSquare at the start of every snapshot and sets it
 * back only when LootMenu.show gets past InteractActions.ready and the loot
 * check. During a container open animation ready() is false, so lootSquare
 * stays null and Models.own never marks the Shelf Contents 3D model, which is
 * why the outline vanished as soon as the animation started.
 *
 * Ground loot (0) and containers (2) get their scene target refreshed here on
 * every snapshot, animation included. THING targets (4: doors, windows,
 * sinks, switches, plain furniture) are cleared so the aim no longer outlines
 * them.
 */
public final class AimTarget {
    private static final int GROUND = 0;
    private static final int OBJECT = 2;
    private static final int THING = 4;

    private static Field targetField;
    private static Field kindField;
    private static Field squareField;
    private static Field objectField;
    private static Field lootSquareField;
    private static Method ownerMethod;
    private static boolean ready;
    private static boolean failed;
    private static int notes;
    private static Object lastSquare;
    private static int lastKind = -1;

    private AimTarget() {}

    public static void warmUp() {
        if (failed) return;
        try {
            resolve();
            System.out.println("[VLOJG] hook armed: LootMenu.target + LootTargets.owner resolved");
        } catch (Throwable t) {
            failed = true;
            System.out.println("[VLOJG] warm-up failed: " + t);
        }
    }

    private static void resolve() throws Exception {
        if (ready) return;
        ClassLoader loader = AimTarget.class.getClassLoader();
        Class<?> lootMenu = Class.forName("viewpoint.interact.LootMenu", false, loader);
        targetField = lootMenu.getDeclaredField("target");
        targetField.setAccessible(true);
        Class<?> targetType = targetField.getType();
        kindField = targetType.getDeclaredField("kind");
        kindField.setAccessible(true);
        squareField = targetType.getDeclaredField("square");
        squareField.setAccessible(true);
        objectField = targetType.getDeclaredField("object");
        objectField.setAccessible(true);
        Class<?> lootTargets = Class.forName("viewpoint.interact.LootTargets", false, loader);
        ownerMethod = lootTargets.getDeclaredMethod("owner", targetType);
        ownerMethod.setAccessible(true);
        lootSquareField = Frame.class.getDeclaredField("lootSquare");
        lootSquareField.setAccessible(true);
        ready = true;
    }

    public static void afterSnapshot(Object frameObject) {
        if (failed) return;
        try {
            if (!(frameObject instanceof Frame)) return;
            Frame frame = (Frame) frameObject;
            SceneData scene = frame.scene;
            if (scene == null) return;
            resolve();
            Object target = targetField.get(null);
            if (target == null) { AimState.clear(); return; }
            Object object = objectField.get(target);
            int kind = ((Integer) kindField.get(target)).intValue();
            Object squareObject = squareField.get(target);
            if (!(squareObject instanceof IsoGridSquare)) { AimState.clear(); return; }
            IsoGridSquare aimed = (IsoGridSquare) squareObject;
            AimState.set(kind, object);
            if (kind == THING) {
                scene.targetMesh = null;
                scene.targetOwner = -1;
                scene.targetSquare = -1;
                lootSquareField.set(frame, null);
                note(scene, object, kind, -1, aimed);
                return;
            }
            if (kind == GROUND || kind == OBJECT) {
                Tag.clear();
                int owner = ((Integer) ownerMethod.invoke(null, target)).intValue();
                scene.targetMesh = ChunkCache.meshOn(aimed);
                scene.targetOwner = owner;
                scene.targetSquare = (owner >> 2) & 63;
                lootSquareField.set(frame, aimed);
                note(scene, object, kind, owner, aimed);
                return;
            }
            note(scene, object, kind, -1, aimed);
        } catch (Throwable t) {
            failed = true;
            System.out.println("[VLOJG] hook disabled: " + t);
        }
    }

    private static void note(SceneData scene, Object object, int kind, int owner, IsoGridSquare aimed) {
        if (aimed == lastSquare && kind == lastKind) return;
        lastSquare = aimed;
        lastKind = kind;
        if (notes >= 60) return;
        notes++;
        try {
            int match = 0;
            int[] owners = scene.targetMesh == null ? null : scene.targetMesh.runs;
            if (owners != null && owner >= 0) {
                for (int i = 0; i < owners.length; i += 3) {
                    if (owners[i] == owner) match++;
                }
            }
            System.out.println("[VLOJG] aim kind " + kind
                    + " class " + (object == null ? "-" : object.getClass().getSimpleName())
                    + " sprite " + spriteOf(object)
                    + " owner 0x" + Integer.toHexString(owner)
                    + " match " + match
                    + " square " + scene.targetSquare
                    + " models " + (scene.targetMesh != null && scene.targetMesh.hasModels()));
        } catch (Throwable ignored) {
        }
    }

    private static String spriteOf(Object object) {
        if (object == null) return "-";
        try {
            Method getSprite = object.getClass().getMethod("getSprite");
            Object sprite = getSprite.invoke(object);
            if (sprite instanceof IsoSprite) {
                String name = ((IsoSprite) sprite).getName();
                return (name == null ? "null" : name) + " tag " + Tag.of((IsoSprite) sprite);
            }
            return "?";
        } catch (Throwable t) {
            return "?";
        }
    }
}
