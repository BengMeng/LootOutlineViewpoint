package vlojg;

import me.zed_0xff.zombie_buddy.Patch;

@Patch(className = "viewpoint.light.OwnedLight", methodName = "modelLightAt", warmUp = true)
public final class Patch_ModelLightAt {
    @Patch.OnEnter
    public static void enter(@Patch.Argument(0) int x, @Patch.Argument(1) int y, @Patch.Argument(2) int z) {
        ShelfState.square(x, y, z);
    }
}
