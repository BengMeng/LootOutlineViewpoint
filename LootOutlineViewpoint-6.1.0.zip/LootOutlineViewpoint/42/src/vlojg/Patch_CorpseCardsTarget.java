package vlojg;

import me.zed_0xff.zombie_buddy.Patch;

@Patch(className = "viewpoint.render.CorpseCards", methodName = "drawTarget", warmUp = true)
public final class Patch_CorpseCardsTarget {
    @Patch.OnEnter(skipOn = true)
    public static boolean enter() {
        return AimState.kind() != AimState.BODY;
    }
}
