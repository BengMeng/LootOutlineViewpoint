package vlojg;

import viewpoint.core.Frame;
import viewpoint.render.ModelDraws;
import zombie.iso.IsoGridSquare;
import zombie.iso.IsoObject;

/**
 * Keeps the aimed container's outline lit while ShelfContents3D plays a door
 * animation.
 *
 * While a rig animates, ShelfContents3D hides Viewpoint's own pack model for
 * that object (Anim.hides) and draws a replacement through ModelDraws.add, so
 * PackDraws.drawTarget has no model left to outline and the highlight blinks
 * out. This marks the replacement draws for the aimed square with TARGET so
 * the outline stays on screen for the whole animation.
 */
public final class ShelfState {
    private static boolean inside;
    private static ModelDraws models;
    private static boolean squareKnown;
    private static int squareX;
    private static int squareY;
    private static int squareZ;

    private ShelfState() {}

    public static void enter(Object frame) {
        inside = frame instanceof Frame;
        models = inside ? ((Frame) frame).scene.models : null;
        squareKnown = false;
    }

    public static void exit() {
        inside = false;
        models = null;
        squareKnown = false;
    }

    public static void square(int x, int y, int z) {
        if (!inside) return;
        squareX = x;
        squareY = y;
        squareZ = z;
        squareKnown = true;
    }

    public static void added() {
        if (!inside || !squareKnown || models == null) return;
        if (AimState.kind() != AimState.OBJECT) return;
        IsoObject target = AimState.target();
        if (target == null) return;
        IsoGridSquare square = target.getSquare();
        if (square == null || square.x != squareX || square.y != squareY || square.z != squareZ) return;
        int index = models.count() - 1;
        if (index >= 0) models.target(index);
    }
}
