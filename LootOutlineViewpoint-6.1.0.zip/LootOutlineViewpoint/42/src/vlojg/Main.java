package vlojg;

public final class Main {
    public static void main(String[] args) {
        System.out.println("[VLOJG] Viewpoint loot outline (By JG) v6.1 loaded");
        try {
            AimTarget.warmUp();
        } catch (Throwable t) {
            System.out.println("[VLOJG] warm-up failed: " + t);
        }
    }
}
