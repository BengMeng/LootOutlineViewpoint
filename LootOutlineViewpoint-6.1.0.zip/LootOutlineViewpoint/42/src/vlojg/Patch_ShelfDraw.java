package vlojg;

import me.zed_0xff.zombie_buddy.Patch;

@Patch(className = "shelfcontents.Draw", methodName = "draw", warmUp = false)
public final class Patch_ShelfDraw {
    @Patch.OnEnter
    public static void enter(@Patch.Argument(0) Object frame) {
        ShelfState.enter(frame);
    }

    @Patch.OnExit
    public static void exit() {
        ShelfState.exit();
    }
}
