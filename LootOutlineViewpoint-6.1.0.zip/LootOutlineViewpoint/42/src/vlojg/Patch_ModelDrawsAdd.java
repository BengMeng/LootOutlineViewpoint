package vlojg;

import me.zed_0xff.zombie_buddy.Patch;

@Patch(className = "viewpoint.render.ModelDraws", methodName = "add", warmUp = true)
public final class Patch_ModelDrawsAdd {
    @Patch.OnExit
    public static void exit() {
        ShelfState.added();
    }
}
