package vlojg;

import java.util.ArrayList;

import viewpoint.core.Frame;
import viewpoint.packs.ModelPacks;
import viewpoint.packs.PackBind;
import zombie.inventory.InventoryItem;
import zombie.iso.IsoGridSquare;
import zombie.iso.IsoObject;
import zombie.iso.sprite.IsoSprite;
import zombie.iso.sprite.IsoSpriteInstance;

/**
 * Shared aim state for the draw-time filters.
 *
 * Viewpoint draws two things by square, not by object: pack models
 * (PackDraws.drawTarget with a 1L << square mask) and animated models
 * (Models.own marks every model captured on frame.lootSquare). On a tile with
 * a container, a TV, a wall clock and a window that outlines all of them.
 *
 * PackDraws asks PackModels.get for each model while it draws, so the lookup is
 * narrowed to the models bound to the aimed object's sprites. Models.own is
 * called per object, so frame.lootSquare is hidden while a non-aimed object is
 * captured.
 */
public final class AimState {
    static final int GROUND = 0;
    static final int BODY = 1;
    static final int OBJECT = 2;
    static final int THING = 4;

    private static volatile int kind = -1;
    private static volatile IsoObject object;

    private static boolean inPackTarget;
    private static final int[] allowedModels = new int[16];
    private static int allowedCount;
    private static final ThreadLocal<IsoGridSquare> savedSquare = new ThreadLocal<>();

    private AimState() {}

    public static void set(int targetKind, Object targetObject) {
        kind = targetKind;
        object = targetObject instanceof IsoObject ? (IsoObject) targetObject : null;
    }

    public static void clear() {
        kind = -1;
        object = null;
    }

    public static int kind() {
        return kind;
    }

    public static IsoObject target() {
        return object;
    }

    public static boolean enterPackTarget() {
        inPackTarget = false;
        allowedCount = 0;
        IsoObject target = object;
        if (kind != OBJECT || target == null) return true;
        add(target.getSprite());
        add(target.getOverlaySprite());
        ArrayList<IsoSpriteInstance> attached = target.getAttachedAnimSprite();
        if (attached != null) {
            for (int i = 0; i < attached.size(); i++) {
                IsoSpriteInstance instance = attached.get(i);
                if (instance != null) add(instance.parentSprite);
            }
        }
        if (allowedCount == 0) return true;
        inPackTarget = true;
        return false;
    }

    private static void add(IsoSprite sprite) {
        if (sprite == null) return;
        PackBind bind = ModelPacks.bind(sprite);
        if (bind == null || bind.model == null) return;
        int index = bind.model.index;
        for (int i = 0; i < allowedCount; i++) {
            if (allowedModels[i] == index) return;
        }
        if (allowedCount < allowedModels.length) allowedModels[allowedCount++] = index;
    }

    public static void exitPackTarget() {
        inPackTarget = false;
        allowedCount = 0;
    }

    public static boolean packFiltering() {
        return inPackTarget;
    }

    public static boolean packAllowed(int index) {
        for (int i = 0; i < allowedCount; i++) {
            if (allowedModels[i] == index) return true;
        }
        return false;
    }

    public static void beforeOwn(Frame frame, IsoGridSquare square, IsoObject owned, InventoryItem item) {
        if (frame == null || square == null || square != frame.lootSquare) return;
        if (allowedModel(owned, item)) return;
        savedSquare.set(square);
        frame.lootSquare = null;
    }

    public static void afterOwn(Frame frame) {
        IsoGridSquare saved = savedSquare.get();
        if (saved == null) return;
        savedSquare.remove();
        if (frame != null) frame.lootSquare = saved;
    }

    private static boolean allowedModel(IsoObject owned, InventoryItem item) {
        if (kind == OBJECT) return owned != null && owned == object;
        if (kind == GROUND) return owned == null && item != null;
        return false;
    }
}
