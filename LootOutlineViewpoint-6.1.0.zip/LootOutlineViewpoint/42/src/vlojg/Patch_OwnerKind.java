package vlojg;

import me.zed_0xff.zombie_buddy.Patch;
import zombie.iso.sprite.IsoSprite;

@Patch(className = "viewpoint.visibility.Edges", methodName = "ownerKind", warmUp = true)
public final class Patch_OwnerKind {
    @Patch.OnExit
    public static void exit(@Patch.Argument(0) IsoSprite sprite) {
        Tag.set(sprite);
    }
}
