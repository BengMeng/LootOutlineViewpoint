package vlojg;

import me.zed_0xff.zombie_buddy.Patch;

@Patch(className = "viewpoint.render.PackDraws", methodName = "drawTarget", warmUp = true)
public final class Patch_PackDrawsTarget {
    @Patch.OnEnter(skipOn = true)
    public static boolean enter() {
        return AimState.enterPackTarget();
    }

    @Patch.OnExit
    public static void exit() {
        AimState.exitPackTarget();
    }
}
