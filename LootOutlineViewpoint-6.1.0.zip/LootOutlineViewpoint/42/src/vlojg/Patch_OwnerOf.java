package vlojg;

import me.zed_0xff.zombie_buddy.Patch;

@Patch(className = "viewpoint.visibility.Owner", methodName = "of", warmUp = true)
public final class Patch_OwnerOf {
    @Patch.OnExit
    public static void exit(@Patch.Argument(0) int square, @Patch.Argument(1) int kind,
            @Patch.Return(readOnly = false) int owner) {
        owner = Tag.apply(square, kind, owner);
    }
}
