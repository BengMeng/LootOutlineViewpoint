package vlojg;

import zombie.iso.sprite.IsoSprite;

/**
 * Adds a per-sprite tag to Viewpoint owners so that a tile can hold several
 * independently addressable objects (door vs wall, cupboard vs floor overlay).
 *
 * Owner layout stays 8 bits of square+kind at the bottom, tag above:
 *   owner = tag << 8 | square << 2 | kind
 * WorldMesher computes the owner right after Edges.ownerKind, so the sprite
 * that is being meshed is known there. LootTargets.owner runs through the same
 * two methods for the aimed object, which makes both sides agree on the tag.
 */
public final class Tag {
    private static final int SHIFT = 8;
    private static final int LIMIT = 32766;

    private static final ThreadLocal<int[]> PENDING = ThreadLocal.withInitial(() -> new int[2]);

    private Tag() {}

    public static void clear() {
        int[] pending = PENDING.get();
        pending[0] = 0;
        pending[1] = 0;
    }

    public static void set(IsoSprite sprite) {
        int[] pending = PENDING.get();
        pending[0] = 0;
        pending[1] = 0;
        if (sprite == null) return;
        int tag = of(sprite);
        pending[0] = tag;
        pending[1] = tag;
    }

    public static int of(IsoSprite sprite) {
        String name = sprite.getName();
        int hash = name != null && !name.isEmpty() ? name.hashCode() : System.identityHashCode(sprite);
        hash ^= hash >>> 16;
        return 1 + ((hash & 0x7fffffff) % LIMIT);
    }

    public static int apply(int square, int kind, int owner) {
        int[] pending = PENDING.get();
        int tag = pending[0];
        if (tag != 0) {
            pending[0] = 0;
            if (kind == 3) return owner;
            if (kind < 0) owner = square << 2;
            return owner | (tag << SHIFT);
        }
        if ((kind == 1 || kind == 2) && pending[1] != 0) {
            return owner | (pending[1] << SHIFT);
        }
        pending[1] = 0;
        return owner;
    }

    public static int square(int owner, int square) {
        return owner < 0 ? owner >> 2 : (owner >> 2) & 63;
    }
}
