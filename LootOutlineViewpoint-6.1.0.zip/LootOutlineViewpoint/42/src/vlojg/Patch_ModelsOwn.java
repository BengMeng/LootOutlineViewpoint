package vlojg;

import me.zed_0xff.zombie_buddy.Patch;
import viewpoint.core.Frame;
import zombie.inventory.InventoryItem;
import zombie.iso.IsoGridSquare;
import zombie.iso.IsoObject;

@Patch(className = "viewpoint.models.Models", methodName = "own", warmUp = true)
public final class Patch_ModelsOwn {
    @Patch.OnEnter
    public static void enter(@Patch.Argument(0) Frame frame, @Patch.Argument(2) IsoGridSquare square,
            @Patch.Argument(3) IsoObject object, @Patch.Argument(4) InventoryItem item) {
        AimState.beforeOwn(frame, square, object, item);
    }

    @Patch.OnExit
    public static void exit(@Patch.Argument(0) Frame frame) {
        AimState.afterOwn(frame);
    }
}
