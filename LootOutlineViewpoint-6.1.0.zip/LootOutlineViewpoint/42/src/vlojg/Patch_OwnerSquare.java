package vlojg;

import me.zed_0xff.zombie_buddy.Patch;

@Patch(className = "viewpoint.visibility.Owner", methodName = "square", warmUp = true)
public final class Patch_OwnerSquare {
    @Patch.OnExit
    public static void exit(@Patch.Argument(0) int owner, @Patch.Return(readOnly = false) int square) {
        square = Tag.square(owner, square);
    }
}
