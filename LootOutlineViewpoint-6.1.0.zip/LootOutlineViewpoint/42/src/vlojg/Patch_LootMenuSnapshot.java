package vlojg;

import me.zed_0xff.zombie_buddy.Patch;

@Patch(className = "viewpoint.interact.LootMenu", methodName = "snapshot", warmUp = true)
public final class Patch_LootMenuSnapshot {
    @Patch.OnExit
    public static void exit(@Patch.Argument(0) Object frame) {
        AimTarget.afterSnapshot(frame);
    }
}
