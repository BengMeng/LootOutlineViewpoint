package vlojg;

import me.zed_0xff.zombie_buddy.Patch;
import viewpoint.render.PackModel;

@Patch(className = "viewpoint.render.PackModels", methodName = "get", warmUp = true)
public final class Patch_PackModelsGet {
    @Patch.OnExit
    public static void exit(@Patch.Argument(0) int index, @Patch.Return(readOnly = false) PackModel model) {
        if (model != null && AimState.packFiltering() && !AimState.packAllowed(index)) {
            model = null;
        }
    }
}
