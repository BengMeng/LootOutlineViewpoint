# Loot Outline Viewpoint

Version 6.1.0 — author: JG

Highlights only the object you aim at: the aimed container or ground item and its 3D model. Every world sprite carries its own tag, so no other object on the same tile is outlined, and the aim stays bound to the aimed square while an animated container plays.

Works alongside Shelf Contents 3D (Viewpoint): when its door animation hides the container model, the outline stays lit on the animated rig instead of disappearing.

Doors, windows, sinks, switches, plain furniture, floors, walls and corpses are never outlined.

Standalone: only ZombieBuddy and Viewpoint are required.

## Requirements

- Project Zomboid Build 42, version 42.21 or newer
- ZombieBuddy 2.3.0 or newer
- Viewpoint (plus the 3D model packs you normally use)
- Optional: Shelf Contents 3D (Viewpoint) — supported, not required

Do not enable ViewpointObjectHighlightFix together with this mod; the two are incompatible by design.

## Install (manual)

1. Extract the `LootOutlineViewpoint` folder into `%USERPROFILE%\Zomboid\mods\` so that `mods\LootOutlineViewpoint\42\mod.info` exists.
2. Enable the mod in the mod list, after ZombieBuddy and Viewpoint. If you use Shelf Contents 3D, keep it before this mod as well.
3. On first launch, ZombieBuddy asks you to approve the mod's jar. The full source is in `42\src\vlojg\` if you want to read it before approving.

Mod id: `ViewpointLootOutlineByJG` (use this in a server's `Mods=` list).
The jar is client-only (`media/java/client/`), so a dedicated server skips it; for multiplayer, add the mod id to the server's `Mods=` list to keep mod lists matched.

## Verify it loaded

`console.txt` shows:

```
[VLOJG] Viewpoint loot outline (By JG) v6.1 loaded
```

## Troubleshooting

- No outline at all: make sure Viewpoint is enabled and working, and that ViewpointObjectHighlightFix is disabled.
- Outline stays on the wrong object: report it with the aim spot (container type, tile) and your `console.txt`.
- After updating the jar: let ZombieBuddy finish its approval prompt, then restart the client.

## Changelog

- 6.1.0 — outline stays lit while Shelf Contents 3D plays a container door animation; per-sprite tagging so only the aimed object is outlined.
- 6.0.0 — initial public build: aim-bound outline for the aimed container or ground item and its 3D model.

## AI disclosure

The code and the text for this mod were written with AI assistance. It was tested in game on Build 42.21. As with any mod, back up your saves before installing.

## Credits

Thanks to the authors of Viewpoint, ZombieBuddy and Shelf Contents 3D — this mod is built on their work. Source is included for reading and reference; please do not reupload it as your own.
